# Devops-Nodejs

This is used for the DevOps engineer interview demo.

Only using Jenkins to compelte the CI/CD process.

#Environment
On-premise k8s cluster, GitLab, Jenkins, Harbor

