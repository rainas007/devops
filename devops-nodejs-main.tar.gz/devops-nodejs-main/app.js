const http = require('http');
const os = require('os');
console.log("Kubia Server starting");

var handler = function(request, response){
	console.log("Received Request from" + request.connection.remoteAddress);
	response.writeHead(200);
    //Get the hostname of the k8s worker-nodes
	response.end("New code updated, you've hit " + os.hostname() + "\n");
};
var www = http.createServer(handler);
www.listen(8080);
